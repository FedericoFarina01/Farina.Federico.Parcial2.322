package Config;

import java.nio.file.Path;
import java.nio.file.Paths;


public interface RutasArchivos {
    
    
    static final String BASE = "src/resources";
    
    static final String BIN = "recetas.bin";
    
    static final String CSV = "recetas.csv";

    
    static Path getRutaCSV(){
        return Paths.get(BASE, CSV);
    }
    
    static Path getRutaBin(){
        return Paths.get(BASE, BIN);
    }
    
    static String getRutaCSVString(){
        return getRutaCSV().toString();
    }
    
    static String getRutaBinString(){
        return getRutaBin().toString();
    }  
    
}