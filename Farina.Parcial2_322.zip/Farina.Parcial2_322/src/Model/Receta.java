package Model;

import java.io.Serializable;
import java.util.Objects;


public class Receta implements Comparable<Receta>, CSVSerializable, Serializable {

    private static final long serialVersionUID = 1L; 
    private final int id;
    private final String nombre;
    private final String autor;
    private final TipoReceta tipoReceta;

    public Receta(int id, String nombre, String autor, TipoReceta tipoReceta) {
        validarId(id);
        this.id = id;
        validarNombre(nombre);
        this.nombre = nombre;
        validarAutor(autor);
        this.autor = autor;
        this.tipoReceta = tipoReceta;
    }
    
    
    private void validarId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("El ID debe ser un número positivo.");
        }
    }

    private void validarNombre(String nombre) {
        if (nombre == "") {
            throw new IllegalArgumentException("Falta el nombre de la receta");
        }
    }

    private void validarAutor(String autor) {
        if (autor == "") {
            throw new IllegalArgumentException("Falta el nombre del autor");
        }
    }



    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getAutor() {
        return autor;
    }

    public TipoReceta getTipoReceta() {
        return tipoReceta;
    }

    
    
    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof Receta r)){  
            return false;
        }
        return this.id == r.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
    
    
    @Override
    public int compareTo(Receta otraReceta) {
        return Integer.compare(otraReceta.id, this.id); // El enunciado pide orden natural DESCENDENTE
    }


    @Override
    public String toString() {
        return "Receta{" + "id=" + id + ", nombre=" + nombre + ", autor=" + autor + ", tipoReceta=" + tipoReceta + '}';
    }

    

    @Override
    public String toCSV() { 
        return id + "," + nombre + "," + autor + "," + tipoReceta;
    }

    public static Receta fromCSV(String linea) { 
        if (linea.endsWith("\n")) {
            linea = linea.substring(0, linea.length() - 1);
        }
        String[] partes = linea.split(",");
        if (partes.length == 4) {
            int id = Integer.parseInt(partes[0].trim());
            String nombre = partes[1].trim();
            String autor = partes[2].trim();
            TipoReceta tipoReceta = TipoReceta.valueOf(partes[3].strip());  

            return new Receta(id, nombre, autor, tipoReceta);
        }
        return null; 
    }

    public static String toCSVHeader() {
        return "ID,NOMBRE,AUTOR,TIPO_RECETA";
    }
}
