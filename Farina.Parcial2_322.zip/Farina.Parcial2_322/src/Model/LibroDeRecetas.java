package Model;

import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Function;


public class LibroDeRecetas<T extends CSVSerializable> implements Serializable {

    private static final long serialVersionUID = 1L;
    private List<T> items = new ArrayList<>();

    
    public void agregar(T item) { 
        validarRecetaRepetida(item);
        items.add(item);
    }
    
    
    
    public T obtenerPorIndice(int indice) { 
        validarIndice(indice);
        return items.get(indice);
    }
       
    
    public void eliminarPorIndice(int index) { 
        validarIndice(index);
        items.remove(index);
    }
    
    
    private void validarIndice(int indice) {
        if (indice < 0 || indice >= items.size()) {
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }

    private void validarRecetaRepetida(T item) {
        if (items.contains(item)) {
            throw new IllegalArgumentException("La receta ya se encuentra en el libro");
        }
    }

    
    public List<T> filtrar(Predicate<? super T> criterio) { 
        List<T> resultado = new ArrayList<>();
        for (T item : items) {
            if (criterio.test(item)) resultado.add(item);
        }
        return resultado;
    }

    // Ordenar por orden natural
    public void ordenar() {
        if (!items.isEmpty() && items.get(0) instanceof Comparable) {
            items.sort((Comparator<? super T>) Comparator.reverseOrder());
        } else {
            throw new UnsupportedOperationException("El tipo de elemento no es Comparable para orden natural.");
        }
    }

    // Ordenar usando Comparator
    public void ordenar(Comparator<? super T> comparador) {
        items.sort(comparador);
    }


    
    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T item : items) {
            accion.accept(item);
        }
    }

    
    public void guardarEnArchivo(String rutaArchivo) throws IOException {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(rutaArchivo))) {
            salida.writeObject(items);
        }
    }
    
    
    public void cargarDesdeArchivo(String rutaArchivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(rutaArchivo))) {
            this.items = (List<T>) entrada.readObject();
        }
    }


    public void guardarEnCSV(String rutaArchivo) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivo))) {
            writer.write(Receta.toCSVHeader() + "\n");
            for (T elemento : items) {
                writer.write(elemento.toCSV());
                writer.newLine();
            }
        }
    }


    public void cargarDesdeCSV(String rutaArchivo, Function<String, T> fromCSVFunction) throws IOException {   
        try (BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo))) {
            items.clear();
            reader.readLine();
            String linea;
            while ((linea = reader.readLine()) != null) {
                T item = fromCSVFunction.apply(linea);
                if (item != null) {
                    items.add(item);
                }
            }
        }
    }
    
}
