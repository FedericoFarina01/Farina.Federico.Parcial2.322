
package Model;


public enum TipoReceta {
    ENTRADA, PLATO_PRINCIPAL, POSTRE, VEGETARIANA, VEGANA, SIN_TACC;
}
