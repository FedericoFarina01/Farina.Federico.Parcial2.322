
package Main;

import Config.RutasArchivos;
import Model.LibroDeRecetas;
import Model.Receta;
import Model.TipoReceta;
import java.io.IOException;
import java.util.Comparator;


public class Main {

    
    public static void main(String[] args) {
        try {
            // Crear un libro de recetas
            LibroDeRecetas<Receta> libro = new LibroDeRecetas<>();
            
            libro.agregar(new Receta(1, "Tarta de Verdura", "Abuela Rosa",
           TipoReceta.VEGETARIANA));        
            
            libro.agregar(new Receta(2, "Pollo al horno", "Juan Pérez",
           TipoReceta.PLATO_PRINCIPAL));
            
            libro.agregar(new Receta(3, "Ensalada César", "Laura Ruiz", TipoReceta.ENTRADA));         
            
            libro.agregar(new Receta(4, "Brownie", "Chef Martín", TipoReceta.POSTRE));
            
            libro.agregar(new Receta(5, "Pan sin gluten", "Lucía Gómez", TipoReceta.SIN_TACC));
            
            
            // Mostrar todas las recetas
            System.out.println("Libro de recetas:");
            libro.paraCadaElemento(receta -> System.out.println(receta));
            
            
            // Filtrar recetas por tipo Entrada
            System.out.println("\nRecetas Entrada:");
            libro.filtrar(receta -> receta.getTipoReceta()== TipoReceta.ENTRADA)
            .forEach(receta -> System.out.println(receta));
            
            
            // Filtrar recetas cuyo nombre contiene "ensalada"
            System.out.println("\nRecetas que contienen 'ensalada':");
            libro.filtrar(receta -> receta.getNombre().toLowerCase().contains("ensalada"))
            .forEach(receta -> System.out.println(receta));
            
            
            // Ordenar recetas por ID (orden natural)            --> COMENTARIO DEL ALUMNO: EL enunciado pide que sea descendente
            System.out.println("\nRecetas ordenadas por ID:");
            libro.ordenar((receta1, receta2) -> receta1.compareTo(receta2));             
            libro.paraCadaElemento(receta -> System.out.println(receta));
            
            
            // Ordenar recetas por nombre
            System.out.println("\nRecetas ordenadas por nombre:");
            libro.ordenar((receta1, receta2) -> receta1.getNombre().compareTo(receta2.getNombre()));
            
            
            // Guardar el libro en archivo binario
            libro.guardarEnArchivo(RutasArchivos.getRutaBinString());
            
            
            // Cargar el libro desde archivo binario
            LibroDeRecetas<Receta> libroCargado = new LibroDeRecetas<>();
            libroCargado.cargarDesdeArchivo(RutasArchivos.getRutaBinString());
            System.out.println("\nRecetas cargadas desde archivo binario:");
            libroCargado.paraCadaElemento(receta -> System.out.println(receta));
            
            
            // Guardar el libro en archivo CSV
            libro.guardarEnCSV(RutasArchivos.getRutaCSVString());
            
            
            // Cargar el libro desde archivo CSV
            libroCargado.cargarDesdeCSV(RutasArchivos.getRutaCSVString(), Receta::fromCSV);
            System.out.println("\nRecetas cargadas desde archivo CSV:");
            libroCargado.paraCadaElemento(receta -> System.out.println(receta));
            
            } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
 }
}
